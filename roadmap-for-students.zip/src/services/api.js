import Anthropic from '@anthropic-ai/sdk';

// We initialize safely since the API key might exist in .env
const apiKey = import.meta.env.VITE_ANTHROPIC_API_KEY;

export const anthropic = apiKey ? new Anthropic({
  apiKey,
  dangerouslyAllowBrowser: true, // Typically unsafe for production frontend, but required for this local/demo architecture
}) : null;

export const generateLearningRoadmap = async ({ goal, skillLevel, timeCommitment, learningStyle }) => {
  if (!anthropic) {
    throw new Error("Anthropic API key is missing. Please add VITE_ANTHROPIC_API_KEY to your .env file.");
  }

  const prompt = `
You are an expert educational curriculum designer. Create a personalized learning roadmap for the following:
- Learning Goal: ${goal}
- Current Skill Level: ${skillLevel}
- Available Time: ${timeCommitment} hours per week
- Preferred Learning Style: ${learningStyle}

Organize the learning journey into a highly structured JSON object. 
Ensure your response is ONLY a strictly valid JSON object and contains no markdown formatting around it (no \`\`\`json).

The JSON object must have a single key "phases", which is an array of objects representing chronological learning phases.
If the skill level is "intermediate", you may skip absolute beginner basics. If "advanced", skip to advanced/expert topics.

For each phase, provide:
- "id": A unique string ID (e.g., "phase-1")
- "title": Phase title (e.g., "Phase 1: Deep Dive into React")
- "description": A short motivating sentence.
- "estimatedTime": Estimated time to complete given the ${timeCommitment} hrs/week (e.g., "4 weeks", "12 weeks")
- "topics": An array of specific learning milestones.

For each topic, provide:
- "name": The exact concept to learn.
- "type": "Video", "Article", "Course", "Project", "Book", or "Documentation"
- "source": Specifically recommend a real world resource (e.g., "YouTube - Traversy Media", "MDN Docs", "FreeCodeCamp", "Udemy - Maximilian", etc.)
- "cost": "Free" or "Paid"

Here is an example format mapping:
{
  "phases": [
    {
      "id": "phase-1",
      "title": "Phase 1: Fundamentals",
      "description": "Laying the groundwork...",
      "estimatedTime": "4 weeks",
      "topics": [
        {
          "name": "Introduction to Concept X",
          "type": "Video",
          "source": "YouTube",
          "cost": "Free"
        }
      ]
    }
  ]
}

Only Output raw JSON.
`;

  try {
    const response = await anthropic.messages.create({
      model: "claude-3-7-sonnet-20250219", // up to date model
      max_tokens: 3500,
      system: "You are a master curriculum designer who outputs strictly valid JSON without markdown wrapping.",
      messages: [
        { role: "user", content: prompt }
      ]
    });

    const contentText = response.content[0].text.trim();
    // In case the AI includes markdown wrappers like ```json ... ```, strip them out:
    const jsonStr = contentText.replace(/^```json\s*/, '').replace(/```$/, '').trim();
    
    const parsed = JSON.parse(jsonStr);
    if (!parsed || !parsed.phases) {
        throw new Error("Invalid output format from AI.");
    }
    
    return parsed.phases;
  } catch (error) {
    console.error("Error generating roadmap via Anthropic:", error);
    throw new Error(error.message || "Failed to generate roadmap. Please check your API key and try again.");
  }
};
